#pragma once
#define SUTUM_FIRMWARE_VERSION "0.1.0"
